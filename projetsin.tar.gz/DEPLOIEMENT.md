# Déploiement sur Ubuntu Server

Installez Docker Engine et le plugin Docker Compose, puis placez-vous à la racine du projet sur le serveur. Les commandes supposent que votre compte peut utiliser Docker. [Installation officielle sur Ubuntu](https://docs.docker.com/engine/install/ubuntu/)

## Premier démarrage

Créez le fichier de configuration, puis renseignez deux mots de passe distincts. Chaque exécution de `openssl rand -hex 32` génère un mot de passe.

```bash
install -m 600 .env.docker.example .env.docker
openssl rand -hex 32
openssl rand -hex 32
nano .env.docker
```

Par défaut, l’interface est accessible depuis le serveur sur `http://127.0.0.1:3000`. Pour que les appareils du réseau local puissent accéder à l’API, réglez `APP_BIND_ADDRESS` sur l’adresse IP locale du serveur. Réservez cet accès à un réseau de confiance, car certaines routes de gestion des appareils sont accessibles sans authentification.

```bash
docker compose --env-file .env.docker up -d --build
docker compose --env-file .env.docker ps -a
curl -f http://127.0.0.1:3000/
```

Adaptez l’adresse et le port de `curl` si vous avez modifié les paramètres. Compose initialise une nouvelle base MariaDB, attend qu’elle soit prête, puis applique les migrations Prisma. Le service `migrate` doit sortir avec le code 0. Le service `app` reste actif et son contrôle de santé vérifie que l’interface répond. MariaDB est joignable sur le réseau interne de Compose.

## Exploitation

Après avoir récupéré une nouvelle version du projet, relancez `docker compose --env-file .env.docker up -d --build` pour reconstruire l’image et appliquer les migrations disponibles.

```bash
docker compose --env-file .env.docker logs --tail=100 db migrate app
docker compose --env-file .env.docker down
```

Les données restent dans le volume `db-data` après `down`. L’option `down -v` supprime ce volume et toutes les données. Conservez les mots de passe de la première initialisation. Une rotation sur une base existante nécessite aussi de modifier les comptes dans MariaDB.
